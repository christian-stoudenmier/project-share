import os
import requests
import urllib.parse

from flask import redirect, render_template, request, session
from functools import wraps

def _get_request(path, params):
    api_key = '83d234ab35604f9089f1a85ee34f7f5d'
    url = f"https://api.spoonacular.com{path}"
    headers = { "Content-Type": "application/json" }
    params["apiKey"] = api_key
    response = requests.get(url, headers=headers, params=params)
    return response.json()

def find_by_nutrients(min_carbs, max_carbs, min_protein, max_protein, min_calories, max_calories, min_fat, max_fat, number=2):
    path = "/recipes/findByNutrients/"
    params = {
        "minCarbs": min_carbs,
        "maxCarbs": max_carbs,
        "minProtein": min_protein,
        "maxProtein": max_protein,
        "minCalories": min_calories,
        "maxCalories": max_calories,
        "minFat": min_fat,
        "maxFat": max_fat,
        "number": 2
    }
    return _get_request(path, params)

#print(find_by_nutrients(1,2,3,4))

def get_random(tags_r, number=2):
    path = "/recipes/random/"
    params = {
        "tags": tags_r,
        "number": 2
    }
    return _get_request(path, params)

def by_id(id, number=2):
    path = "/recipes/{id}/nutritionWidget.json"
    params = {
        "number": 2,
        "id": id
    }
    return _get_request(path,params)

def recipe_info(id):

    id = request.form.get("id")
    url = f"https://api.spoonacular.com/recipes/{id}/information?includeNutrition=false&apiKey=83d234ab35604f9089f1a85ee34f7f5d"
    print(f'{sourceUrl}')