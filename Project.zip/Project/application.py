import os
import json
import requests
import urllib.parse

from cs50 import SQL
from flask import Flask, flash, jsonify, redirect, render_template, request, session
from flask_session import Session
from tempfile import mkdtemp
from werkzeug.exceptions import default_exceptions, HTTPException, InternalServerError
from werkzeug.security import check_password_hash, generate_password_hash
from datetime import datetime
from delete_me import find_by_nutrients

from helpers import find_by_nutrients, get_random, by_id, recipe_info

#confiqure application
app = Flask(__name__)

# Ensure templates are auto-reloaded
app.config["TEMPLATES_AUTO_RELOAD"] = True

# Ensure responses aren't cached
@app.after_request
def after_request(response):
    response.headers["Cache-Control"] = "no-cache, no-store, must-revalidate"
    response.headers["Expires"] = 0
    response.headers["Pragma"] = "no-cache"
    return response


@app.route("/")
def index():
    """home page"""

    return render_template("index.html")


@app.route("/recipes", methods=["GET", "POST"])
def recipes():

    if request.method == "POST":

        min_carbs = request.form.get("minCarbs", 10, type=int)
        max_carbs = request.form.get("maxCarbs", 100, type=int)
        min_protein = request.form.get("minProtein", 10, type=int)
        max_protein = request.form.get("maxProtein", 100, type=int)
        min_calories = request.form.get("minCalories", 50, type=int)
        max_calories = request.form.get("maxCalories", 800, type=int)
        min_fat = request.form.get("minFat", 1, type=int)
        max_fat = request.form.get("maxFat", 100, type=int)

        r = find_by_nutrients(min_carbs, max_carbs, min_protein, max_protein, min_calories, max_calories, min_fat, max_fat)


        return render_template("recipes_final.html", r=r)
    else:
        return render_template("recipes.html")


@app.route("/random", methods=["GET", "POST"])
def random():


    if request.method == "POST":

        tags_r = request.form.get("tags")

        r = get_random(tags_r)

        return render_template("random_final.html", r=r)
    else:
        return render_template("random.html")


@app.route("/information", methods=["GET", "POST"])
def information():

    recipe_info(id)
    print(sourceUrl)